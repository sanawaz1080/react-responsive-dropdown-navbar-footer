import React from "react";

const Dashboard = () => {
  return <h1 className="dashboard">Dashborad</h1>;
};

export default Dashboard;
