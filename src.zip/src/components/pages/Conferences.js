import React from "react";

const Conferences = () => {
  return <h1 className="conferences">Conferences</h1>;
};

export default Conferences;
