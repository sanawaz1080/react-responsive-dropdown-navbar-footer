import React from "react";

const Journals = () => {
  return <h1 className="journals">Journals</h1>;
};

export default Journals;
