import React from "react";

const Publications = () => {
  return <h1 className="publications">Publications</h1>;
};

export default Publications;
